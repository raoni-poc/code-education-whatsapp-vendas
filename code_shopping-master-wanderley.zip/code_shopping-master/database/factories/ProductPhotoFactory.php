<?php

use Faker\Generator as Faker;

$factory->define(CodeShopping\Models\ProductPhoto::class, function (Faker $faker) {
    return [
        //
    ];
});
