import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'card-error',
  templateUrl: './card-error.component.html',
  styleUrls: ['./card-error.component.css']
})
export class CardErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
