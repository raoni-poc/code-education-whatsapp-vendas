import { NumberFormatBrPipe } from './number-format-br.pipe';

describe('NumberFormatBrPipe', () => {
  it('create an instance', () => {
    const pipe = new NumberFormatBrPipe();
    expect(pipe).toBeTruthy();
  });
});
