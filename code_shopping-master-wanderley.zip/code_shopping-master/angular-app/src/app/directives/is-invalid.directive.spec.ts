import { IsInvalidDirective } from './is-invalid.directive';

describe('IsInvalidDirective', () => {
  it('should create an instance', () => {
    const directive = new IsInvalidDirective();
    expect(directive).toBeTruthy();
  });
});
