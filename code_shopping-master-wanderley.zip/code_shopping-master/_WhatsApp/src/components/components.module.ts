import { NgModule } from '@angular/core';
import { ChatGroupListComponent } from './chat-group-list/chat-group-list';
@NgModule({
	declarations: [ChatGroupListComponent],
	imports: [],
	exports: [ChatGroupListComponent]
})
export class ComponentsModule {}
