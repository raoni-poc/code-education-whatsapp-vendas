export default {
    apiKey: "AIzaSyDxGajDWXDiuqpckdk2YGIE1tl4dFFwBpg",
        authDomain: "codeshopping-6400c.firebaseapp.com",
    databaseURL: "https://codeshopping-6400c.firebaseio.com",
    projectId: "codeshopping-6400c",
    storageBucket: "codeshopping-6400c.appspot.com",
    messagingSenderId: "645505932457"
}