<?php

namespace CodeShopping;

use Illuminate\Database\Eloquent\Model;

class help extends Model
{
    //
}
